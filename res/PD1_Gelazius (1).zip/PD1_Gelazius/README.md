* **Projekto pavadinimas:** Praktinis darbas I
* **Projekto paskirtis:** susipažinti ir įsigilinti į HTML ir CSS kodo rašymą
* **Projekto numatyta auditorija:** žmonės norintys daugiau išmokti apie HTML ir CSS
* **Autorius:** B. J. G.
* **Kursas:** ISKS
* Visa naudojama medija yra sukurta autoriaus B. J. G.
* Puslapis sėkmingai pratestuotas per W3C Markup Validation Service ir CSS Validation Service. Klaidos ištaisytos
* Šią svetainę galite atsidaryti paspaudę *index.html*
* Aplanko struktūra:

&#x20;   		  	pd1-Gelazius/

&#x09;			|-- index.html

&#x09;			|-- pages/

&#x09;			|   |-- html-basics.html

&#x09;			|   |-- css-basics.html

&#x09;			|   `-- process.html

&#x09;			|-- css/

&#x09;			|   `-- styles.css

&#x09;			|-- images/

&#x09;			|	`-- 2.png

&#x09;			|	`-- 10.png

&#x09;			|	`-- 83.png

&#x09;			|	`-- 100.png

&#x09;			|	`-- 2006.png

&#x09;			|	`-- 80085.png

&#x09;			|-- documents/

&#x09;			|   `-- PD1\_Ataskaita\_BJG.pdf

&#x09;			`-- README.md



**Sprendimai:**

* Naudojamos semantinės žymos (header, nav, main, figure, figcaption, article, footer)
* Naudojamas Flexbox modelis su pasikartojančiomis klasėmis
* Naudojamas prisitaikantis dizainas, lankstūs pločiai ir @media užklausa
* Naudojami prieinamumo sprendimai, kaip Tab fokusavimo rodymas, formos etiketės, figcaption, semantinė antraščių seka.





* Generatyvinis DI kodo rašyme nenaudotas.
* Nežinomos CSS savybės ar HTML funkcijos buvo ieškomos w3schools dokumentacijoje.

